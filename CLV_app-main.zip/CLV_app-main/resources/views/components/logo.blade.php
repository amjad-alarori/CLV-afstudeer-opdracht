<style>
.logo {
  
  /* Center child horizontally*/
  display: flex;
  justify-content: center;
}
</style>

<div class="logo">
    <img src="{{ asset('favicon.ico') }}">
</div>
